import React, { useContext } from 'react'
import './css/Product.css'
import { cartContext } from '../App';

export const Product = ({product}) => {
  const {cart,setCart} = useContext(cartContext);
  const name = product.name.length>18 ? product.name.substring(0,17)+".." : product.name;

  const addCart = () => {
    setCart([...cart,product]);
  }
  const removeCart = () => {
    setCart(cart.filter((c) => c.id !== product.id));
  }

  return (
    <div className="product-items">
      <div className="image-con">
        <img src={product.pic} alt="image" />
      </div>
      <div className="product-details">
        <p>{name}</p>
        <div className="price">Price : {product.amt}</div>
        {cart.includes(product) ? (
          <button className='btn-remove' onClick={removeCart}>Remove from Cart</button>
        ):(
          <button className='add' onClick={addCart}>Add to Cart</button>
        )}
      </div>
    </div>
  )
}

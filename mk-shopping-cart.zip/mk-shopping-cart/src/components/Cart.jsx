import React, { useContext, useEffect, useState } from 'react'

import './css/Cart.css'
import { cartContext } from '../App';
export const Cart = () => {
  const {cart} = useContext(cartContext);
  const [totalAmt,setTotalAmt] = useState(0);
  useEffect(() => {
    setTotalAmt(cart.reduce((acc,curr) => acc + parseInt(curr.amt),0))
  } ,[cart])
  return (
    <div className="cart-container">
      <h1>Added Items </h1>
      {cart.map((product) => (
        <div className="cart-items" key={product.id}>
          <img src={product.pic} alt="image" />
          <div className="item-details">
            <h3>{product.name}</h3>
            <h4>Price : {product.amt}</h4>
          </div>
        </div>
      ))}
      <h3>Total Amount : {totalAmt}</h3>
    </div>
  )
}

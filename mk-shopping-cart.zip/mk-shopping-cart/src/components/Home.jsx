import React, {  useState } from 'react'
import data from './producds.json'
import { Product } from './Product'
import './css/Home.css'


export const Home = () => {
  const [products] = useState(data);
  return (
    <div className="product-container">
      {products.map((product) => (
        <Product key={product.id} product={product}/>
      ))}
    </div>
  )
}

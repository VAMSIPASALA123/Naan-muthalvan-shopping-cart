import {Link} from 'react-router-dom'
import './css/Header.css'
import { cartContext } from '../App'
import { useContext } from 'react'
export const Header = () => {
    const {cart} = useContext(cartContext);
    return (
        <div className='navbar'>
            <p>Food Items</ p>
            <ul>
                <li>
                    <Link to={"/"}>Home</Link>
                </li>
                <li>
                    <Link to={"/Cart"}>{(cart.length !==0) && <span className='item-count'>{cart.length}</span>}View Cart</Link>
                </li>
            </ul>
        </div>
    )
}
